from repulo import *
from math import *

repulok = []

def FajlOlvas():
    f = open("utasszallitok.txt", "r", encoding="utf-8")
    f.readline()
    for sor in f:
        egyRepulo = Repulo(sor)
        repulok.append(egyRepulo)
    f.close()

def RepulokSzama():
    return len(repulok)

def BoeingDarabSzam():
    db = 0
    for repulo in repulok:
        if "Boeing" in repulo.Tipus:
            db+=1
    return db

def LegtobbUtas():
    maxRepulo = repulok[0]
    for repulo in repulok:
        if repulo.GetMaxUtas() > maxRepulo.GetMaxUtas():
            maxRepulo = repulo
    return maxRepulo

def FajlIr():
    f = open("utassszallitok_new.txt", "w", encoding="utf-8")
    f.write("típus;év;utas;személyzet;utazósebesség;felszállótömeg;fesztáv\n")
    for repulo in repulok:
        f.write(f"{repulo.Tipus};{repulo.Ev};{repulo.GetMaxUtas()};{repulo.GetMaxSzemelyzet()};{repulo.Utazosebesseg};{repulo.Felszallotomeg/1000:.0f};{repulo.Fesztav*3.2808:.0f}\n")
    f.close()

def Szamol(q0, p0):
    return sqrt(5*((pow(q0/p0+1, 2/7))-1))

def StatKeszit():
    stat = {}
    for repulo in repulok:
        gyarto = repulo.Tipus.split()[0]
        if gyarto in stat.keys():
            stat[gyarto]+=1
        else:
            stat[gyarto] = 1
    return stat
