from fuggvenyek import *

FajlOlvas()
print(f"4.feladat: Adatsorok száma: {RepulokSzama()}")
print(f"5.feladat: Boeing típusok száma: {BoeingDarabSzam()}")
maxRepulo = LegtobbUtas()
print("6.feladat: A legtöbb utast szállító repülőgéptípus")
print(f"\tTípus: {maxRepulo.Tipus}")
print(f"\tElső felszállás: {maxRepulo.Ev}")
print(f"\tUtasok száma: {maxRepulo.Utas}")
print(f"\tSzemélyzet: {maxRepulo.Szemelyzet}")
print(f"\tUtazósebesség: {maxRepulo.Utazosebesseg}")
FajlIr()
q0 = float(input("q0="))
p0 = float(input("p0="))
eredmeny = Szamol(q0,p0)
if eredmeny < 1:
    print(f"Ma={eredmeny}")
else:
    print("Az eredmény nagyobb, mint 1!")

dict = StatKeszit()
print("9.feladat:")
for key, value in dict.items():
    print(f"\t{key}: {value} db")